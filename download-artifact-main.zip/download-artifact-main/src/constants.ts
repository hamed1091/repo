export enum Inputs {
  Name = 'name',
  Path = 'path'
}
export enum Outputs {
  DownloadPath = 'download-path'
}
